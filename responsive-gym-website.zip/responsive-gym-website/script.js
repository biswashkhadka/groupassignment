// Hamburger Menu

var menu = document.getElementById("bar");
var item = document.getElementById("item");

item.style.right = "-300px";
menu.onclick = function () {
  if (item.style.right == "-300px") {
    item.style.right = "0";
  } else {
    item.style.right = "-300px";
  }
};
function Calculate(){
  var height = document.getElementById("h-input").value;
  var weight = document.getElementById("w-input").value;

  var result = parseFloat(weight) /(parseFloat(height)/100)**2;

  if(!isNaN(result)){
      document.getElementById("bmi-output").innerHTML = result;
      if(result < 18.5){
          document.getElementById("bmi-status").innerHTML = "Underweight";
      }
      else if(result < 25){
          document.getElementById("bmi-status").innerHTML = "Healthy";
      }
      else if(result < 30){
          document.getElementById("bmi-status").innerHTML = "Overweight";
      }
      else{
          document.getElementById("bmi-status").innerHTML = "Obesity";
      }
  }
}
function validateForm() {
  // Get form fields
  var name = document.forms["myForm"]["name"].value;
  var address = document.forms["myForm"]["address"].value;
  var contact = document.forms["myForm"]["contact"].value;
  var email = document.forms["myForm"]["email"].value;
  var message = document.forms["myForm"]["message"].value;

  // Validate name
  if (name == "") {
    alert("Please enter your name.");
    return false;
  }

  // Validate address
  if (address == "") {
    alert("Please enter your address.");
    return false;
  }

  // Validate contact
  if (isNaN(contact)) {
    alert("Please enter a valid contact number.");
    return false;
  }

  // Validate email
  var emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.match(emailPattern)) {
    alert("Please enter a valid email address.");
    return false;
  }

  // Validate message
  if (message == "") {
    alert("Please enter a message.");
    return false;
  }

  // If all validation checks pass, return true
  return true;
}

